from ns import ns

# List of packet sizes to simulate
packet_sizes = [128, 256, 512, 1024, 2048]

# Store throughputs for each size
throughputs = []

for size in packet_sizes:
    ns.core.Config.Reset()

    ns.core.LogComponentEnable("UdpEchoClientApplication", ns.core.LOG_LEVEL_WARN)
    ns.core.LogComponentEnable("UdpEchoServerApplication", ns.core.LOG_LEVEL_WARN)

    nodes = ns.network.NodeContainer()
    nodes.Create(2)

    pointToPoint = ns.point_to_point.PointToPointHelper()
    pointToPoint.SetDeviceAttribute("DataRate", ns.core.StringValue("5Mbps"))
    pointToPoint.SetChannelAttribute("Delay", ns.core.StringValue("2ms"))

    devices = pointToPoint.Install(nodes)

    stack = ns.internet.InternetStackHelper()
    stack.Install(nodes)

    address = ns.internet.Ipv4AddressHelper()
    address.SetBase(ns.network.Ipv4Address("10.1.1.0"), ns.network.Ipv4Mask("255.255.255.0"))
    interfaces = address.Assign(devices)

    echoServer = ns.applications.UdpEchoServerHelper(9)
    serverApps = echoServer.Install(nodes.Get(1))
    serverApps.Start(ns.core.Seconds(1.0))
    serverApps.Stop(ns.core.Seconds(10.0))

    serverAddr = interfaces.GetAddress(1).ConvertTo()
    echoClient = ns.applications.UdpEchoClientHelper(serverAddr, 9)
    echoClient.SetAttribute("MaxPackets", ns.core.UintegerValue(1))
    echoClient.SetAttribute("Interval", ns.core.TimeValue(ns.core.Seconds(1.0)))
    echoClient.SetAttribute("PacketSize", ns.core.UintegerValue(size))

    clientApps = echoClient.Install(nodes.Get(0))
    clientApps.Start(ns.core.Seconds(2.0))
    clientApps.Stop(ns.core.Seconds(10.0))

    flowmon_helper = ns.flow_monitor.FlowMonitorHelper()
    monitor = flowmon_helper.InstallAll()
    monitor = flowmon_helper.GetMonitor()

    ns.core.Simulator.Stop(ns.core.Seconds(20.0))
    ns.core.Simulator.Run()

    monitor.CheckForLostPackets()
    classifier = flowmon_helper.GetClassifier()

    for flow_id, flow_stats in monitor.GetFlowStats():
        t = classifier.FindFlow(flow_id)
        if t.destinationPort == 9:
            rx_bytes = flow_stats.rxBytes
            throughput = (rx_bytes * 8) / 18  # 18 seconds total time
            throughputs.append((size, throughput))
            break

    ns.core.Simulator.Destroy()

# Print results
print("Packet Size (Bytes) | Throughput (bps)")
for size, tput in throughputs:
    print(f"{size:<20} {tput:.2f}")
